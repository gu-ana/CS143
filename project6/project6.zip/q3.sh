zcat /home/cs143/data/googlebooks-eng-all-1gram-20120701-s.gz  | cut -f 1,3 | datamash --sort groupby 1 sum 2 | awk '$2 > 1000000'
