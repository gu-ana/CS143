zcat /home/cs143/data/googlebooks-eng-all-1gram-20120701-s.gz | cut -f 1,2,3 | sed '/_/d' | awk '$2 >= 2000' | datamash --sort groupby 1 sum 3 | sort -n -r -k 2,2 | head -10
