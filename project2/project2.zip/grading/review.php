   <html>
<body>
<H1> Review.php </H1>

<h3> Add new review below: </h3>
<form method="post">
Name: <input type="text" name="name" required>
Rating: <input type="text" name="rating" required>
Comment: <textarea name="comment" required cols="40" rows="10"></textarea>

<input type="submit">
</form>
</body>
<?php
error_reporting(-1);
ini_set("display_errors", "1");
ini_set("log_errors", 1);
ini_set("error_log", "tmp/php-error.log");
$id = $_GET['id'];
echo "Movie ID: <input type='text' name='mid' disabled='disabled' value=" .$id.">";
    $db = new mysqli('localhost', 'cs143', '', 'class_db');
    if ($db->connect_errno > 0) {
die('Unable to connect to database [' . $db->connect_error . ']');
}

 $query="CREATE TABLE IF NOT EXISTS Review (
	mid INT,
	name VARCHAR(50),
	rating INT,
	comment VARCHAR(500),
	time TIMESTAMP
	)";

$rs = $db->query($query);
if(!$rs) {
$errmsg = $db->error;
print "Query failed: $errmsg <br>";
exit(1);
}

$name = $_POST['name'];
$rating = $_POST['rating'];
$comment = $_POST['comment'];

if(!is_numeric($rating)) {
print "Query cannot proceed, rating is not an integer/float";
exit(1);
}
$query = "INSERT INTO Review (mid, name, rating, comment, time)
	  VALUES ($id, '$name', $rating, '$comment', NOW())";


echo "$query";

$rs = $db->query($query);
if($rs) {
//succeeded

echo "confirmation text: Your review has successfully been submitted Click <a href='./movie.php?id=". $id."'>". "here to view your review!". "</a>"; 
}
else {

$errmsg = $db->error;
print "Query failed: $errmsg <br>";
    exit(1); 

}
  


?>
</html>
