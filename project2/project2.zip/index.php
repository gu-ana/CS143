

<html>
<head><title>CS143 MySQL-Apache Container</title></head>
<body>
<h1>Welcome to CS143</h1> 
<?php
echo "This is MySQL-Apache Container built for CS143. ";
echo "We hope you enjoy this container as much as we do.";
?>
</body>
</html>
