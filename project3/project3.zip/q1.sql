SELECT id FROM Laureate WHERE givenName LIKE '%Marie%' AND familyName LIKE '%Curie%';
