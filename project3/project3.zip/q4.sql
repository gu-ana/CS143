SELECT COUNT(DISTINCT affiliation_city, affiliation_country)
FROM Prize
WHERE affiliation_name LIKE "%University of California";
