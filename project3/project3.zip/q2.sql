SELECT DISTINCT(affiliation_country) FROM Prize WHERE affiliation_name LIKE "%CERN%";
