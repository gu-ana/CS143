SELECT id
FROM Laureate
WHERE givenName = 'Marie';
