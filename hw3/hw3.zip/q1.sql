SELECT AVG(salary) FROM Instructor;
